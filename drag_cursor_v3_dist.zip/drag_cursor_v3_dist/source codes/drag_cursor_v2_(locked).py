import sys
import json
import time
from pathlib import Path
import pyautogui
import pythoncom
import win32com.client as win32
import ctypes

# Comando de cmd para crear el ejecutable: pyinstaller --onefile --icon=audib.ico "drag_cursor_v2_(locked).py"
# ..... O para la versión sin cmd visible: pyinstaller --onefile --noconsole --icon=audib.ico "drag_cursor_v2_(locked).py"
# ..... Para invocar un "no console" sin que truene: crear archivo run_silent.vbs: CreateObject("Wscript.Shell").Run "drag_cursor_v2.exe", 0, True


SCRIPT_DIR = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) \
             else Path(__file__).resolve().parent

RED = "\033[31m"
GREEN = "\033[32m"
BOLD = "\033[1m"
RESET = "\033[0m"

BASE_DIR = None

def load_config(name):
    global BASE_DIR

    path = SCRIPT_DIR / name
    BASE_DIR = path.parent

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def resolver_ruta(ruta_str):
    ruta = Path(ruta_str)
    if not ruta.is_absolute():
        ruta = (BASE_DIR / ruta).resolve()
    return ruta

def capturar_rango(x1, y1, x2, y2):
    try:
        # Usar el mouse
        pyautogui.moveTo(x1, y1, duration=0.01)
        pyautogui.mouseDown()
        pyautogui.dragTo(x2, y2, duration=0.6)
        pyautogui.mouseUp()

        # Copiar
        pyautogui.hotkey("ctrl", "c")
        time.sleep(0.05)

        print(f"{GREEN}[+] 'Ctrl+C' correcto {RESET} {x1,y1} → {x2,y2}")
        return True
    except Exception as e:
        print(f"{RED}[!] Error captura: {e}{RESET}")
        return False

def iniciar_excel(plantilla):
    plantilla = resolver_ruta(plantilla)
    pythoncom.CoInitialize()

    excel = win32.DispatchEx("Excel.Application")
    excel.Visible = False #...................... EXCEL OCULTO
    excel.ScreenUpdating = False #............... MEGACLAVE
    excel.DisplayAlerts = False

    wb = excel.Workbooks.Open(str(plantilla))

    return excel, wb


def pegar_en_hoja(excel, wb, hoja, celda):
    try:
        try:
            ws = wb.Sheets(hoja)
        except:
            ws = wb.Sheets.Add()
            ws.Name = hoja

        destino = ws.Range(celda)

        # Este método Pega sin requerir UI activa
        ws.Paste(destino)

        print(f"{GREEN}[+] Pegado en hoja {hoja}, celda {celda}{RESET}")

        excel.CutCopyMode = False
        time.sleep(0.01)

    except Exception as e:
        print(f"{RED}[!] Error pegando en {hoja}: {e}{RESET}")


# MAIN ================================================
config = load_config("config.json")
plantilla = config["plantilla"]
operaciones = config["operaciones"]
excel, wb = iniciar_excel(plantilla)#........... Abrir Excel solo una vez (oculto)
app_x, app_y = pyautogui.position()#............ Guardamos dónde está el mouse para volver a la ventana origen

try:
    ctypes.windll.user32.BlockInput(True)
    # Código crítico (durante esta parte, el cursor y el teclado se bloquean)
    for op in operaciones:
        time.sleep(0.01)
        capturar_rango(op["x1"], op["y1"], op["x2"], op["y2"])
        pegar_en_hoja(excel, wb, op["hoja"], op["celda"])

finally:
    ctypes.windll.user32.BlockInput(False)

# REGRESAR EL CURSOR DONDE LO ENCONTRAMOS
pyautogui.click(app_x, app_y)

# Guardar y cerrar
wb.Save()
wb.Close()
excel.Quit()
pythoncom.CoUninitialize()

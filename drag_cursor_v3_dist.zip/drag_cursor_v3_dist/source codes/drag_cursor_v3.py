import sys
import json
import time
from pathlib import Path
import win32api
import win32con
import pyperclip   # pip install pyperclip
import keyboard    # pip install keyboard

# ============================================
# CONFIG / PATHS
# ============================================

SCRIPT_DIR = (
    Path(sys.executable).resolve().parent
    if getattr(sys, "frozen", False)
    else Path(__file__).resolve().parent
)

BASE_DIR = None

def load_config(name):
    global BASE_DIR
    path = SCRIPT_DIR / name
    BASE_DIR = path.parent

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def resolver_ruta(ruta_str):
    ruta = Path(ruta_str)
    if not ruta.is_absolute():
        ruta = (BASE_DIR / ruta).resolve()
    return ruta


# ============================================
# FUNCIONES DE DRAG REAL (win32api)
# ============================================

def mouse_move(x, y):
    win32api.SetCursorPos((x, y))
    time.sleep(0.01)

def mouse_down():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0)

def mouse_up():
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0)

def capturar_rango(x1, y1, x2, y2):
    try:
        # Ir al punto A
        mouse_move(x1, y1)
        time.sleep(0.01)

        # Presionar click y arrastrar
        mouse_down()
        time.sleep(0.05)
        mouse_move(x2, y2)
        time.sleep(0.05)
        mouse_up()

        # Copiar selección
        keyboard.press_and_release("ctrl+c")
        time.sleep(0.15)

        print(f"[+] Captura ok {x1,y1} → {x2,y2}")
        return True
    except Exception as e:
        print(f"[!] Error captura: {e}")
        return False


# ============================================
# GUARDAR CSV
# ============================================

def guardar_csv(texto, ruta_csv):
    ruta_csv = resolver_ruta(ruta_csv)

    ruta_csv.parent.mkdir(parents=True, exist_ok=True)

    # Convertir TAB → coma
    lineas = texto.splitlines()
    filas = [line.replace("\t", ",") for line in lineas]

    with open(ruta_csv, "w", encoding="utf-8", newline="") as f:
        f.write("\n".join(filas))

    print(f"[+] CSV guardado: {ruta_csv}")


# ============================================
# MAIN
# ============================================

config = load_config("config.json")
operaciones = config["operaciones"]

for op in operaciones:

    ok = capturar_rango(op["x1"], op["y1"], op["x2"], op["y2"])

    if not ok:
        print("[!] Saltando operación por error de captura.")
        continue

    # Obtener texto del portapapeles
    datos = pyperclip.paste()

    if not datos.strip():
        print("[!] Portapapeles vacío. ¿Falló la selección?")
        continue

    # Guardar en CSV
    guardar_csv(datos, op["csv"])

print("\n[✓] Proceso terminado.")

import win32api
import time
import os

try:
    while True:
        x, y = win32api.GetCursorPos()

        os.system("cls")
        print(f"X: {x}  |  Y: {y}")

        time.sleep(0.05)
except KeyboardInterrupt:
    pass

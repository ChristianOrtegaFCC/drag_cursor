# Comando de cmd para crear el ejecutable: pyinstaller --onefile --icon=audib.ico "unlock.py"
import ctypes
ctypes.windll.user32.BlockInput(False)
print("Unlocked")